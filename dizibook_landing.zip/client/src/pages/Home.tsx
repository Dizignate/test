import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ChevronRight, MessageCircle, Send, Clock, BookOpen, Zap, Users, Shield } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  const faqs = [
    {
      q: "Does Dizibook work with Instagram?",
      a: "Yes, Dizibook automatically replies to Instagram comments and sends DMs with your booking or WhatsApp link."
    },
    {
      q: "Does Dizibook work with Facebook?",
      a: "Yes, Dizibook automatically replies to Facebook comments and sends DMs with your booking or WhatsApp link."
    },
    {
      q: "Does Dizibook send WhatsApp messages automatically?",
      a: "No, Dizibook sends your WhatsApp link via Instagram and Facebook DMs. Guests can click and contact you on WhatsApp."
    },
    {
      q: "Can I send my booking link automatically?",
      a: "Yes, Dizibook can automatically send your booking link via DM to every guest who comments."
    },
    {
      q: "Is this only for homestays and resorts?",
      a: "Yes, Dizibook Comment Automation is specifically built for homestays and resorts."
    },
    {
      q: "How long does setup take?",
      a: "Setup takes less than 5 minutes. Our team provides free setup support."
    },
    {
      q: "Do I need technical knowledge?",
      a: "No, Dizibook is designed for non-technical users. Anyone can set it up."
    },
    {
      q: "Will it reply to every comment automatically?",
      a: "Yes, Dizibook replies automatically 24/7 to every comment on your posts."
    },
    {
      q: "Can I cancel anytime?",
      a: "Yes, you can cancel anytime from your dashboard. No long-term contracts."
    },
    {
      q: "When does billing start?",
      a: "Billing starts after your 7-day free trial ends. You can cancel anytime before that."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 lg:pt-48 lg:pb-32 bg-white">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold leading-tight mb-6 text-foreground">
                Turn Instagram & Facebook Comments into Direct Booking Enquiries Automatically
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
                Automatically reply to guest comments and send your booking or WhatsApp link via DM — 24/7, without manual work.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <a
                  href="https://homestay.dizibook.com/sign-up"
                  className="btn-primary text-center"
                >
                  Start Free 7-Day Trial
                </a>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                Start your 7-day free trial. Cancel anytime.
              </p>
              <p className="text-sm text-muted-foreground font-medium">
                Built specifically for homestays and resorts.
              </p>
            </div>
            <div className="hidden md:block">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663323380174/MXTkNqPDzzTzIzjR.png"
                  alt="Dizibook automation flow"
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
          
          {/* Mobile Hero Image */}
          <div className="md:hidden mt-12">
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663323380174/MXTkNqPDzzTzIzjR.png"
                alt="Dizibook automation flow"
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="section-spacing bg-card">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-foreground">How It Works</h2>
          <p className="text-center text-muted-foreground text-lg mb-16">
            Works 24/7 without any effort.
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                title: "Connect your Instagram & Facebook page",
                icon: <Users size={40} className="text-primary" />
              },
              {
                step: "2",
                title: "Set your booking link or WhatsApp link once",
                icon: <BookOpen size={40} className="text-primary" />
              },
              {
                step: "3",
                title: "Dizibook replies automatically forever",
                icon: <Zap size={40} className="text-primary" />
              }
            ].map((item, idx) => (
              <div key={idx} className="feature-card text-center">
                <div className="mb-4 flex justify-center">{item.icon}</div>
                <h3 className="text-xl font-bold mb-3 text-foreground">Step {item.step}</h3>
                <p className="text-card-foreground">{item.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Visual Demo Section */}
      <section className="section-spacing bg-white">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-foreground">See How It Works</h2>
          <p className="text-center text-muted-foreground text-lg mb-16">
            Guest comments → Dizibook replies → Guest receives booking link via DM
          </p>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663323380174/MXTkNqPDzzTzIzjR.png"
                alt="Instagram comment automation"
                className="w-full h-auto"
              />
            </div>
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663323380174/xdkQaqAhvYxCrElm.png"
                alt="WhatsApp and booking link delivery"
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="section-spacing bg-card">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-foreground">Powerful Features</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "Unlimited Comment Automation", icon: <MessageCircle size={32} /> },
              { title: "Instagram Automation", icon: <Send size={32} /> },
              { title: "Facebook Automation", icon: <Users size={32} /> },
              { title: "Automatic DM Replies", icon: <Zap size={32} /> },
              { title: "Sends your WhatsApp link via Instagram and Facebook DMs", icon: <Clock size={32} /> },
              { title: "Booking Link Integration", icon: <BookOpen size={32} /> },
              { title: "24/7 Automation", icon: <Clock size={32} /> },
              { title: "Free Setup Support", icon: <Shield size={32} /> }
            ].map((feature, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 border border-border hover:border-primary transition-colors text-center">
                <div className="text-primary mb-4 flex justify-center">{feature.icon}</div>
                <h3 className="text-lg font-bold text-foreground">{feature.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="section-spacing bg-white">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-foreground">Why Choose Dizibook</h2>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              "Increase direct bookings",
              "Respond instantly to guest enquiries",
              "Reduce dependency on OTAs",
              "Capture more leads automatically",
              "Save hours of manual work"
            ].map((benefit, idx) => (
              <div key={idx} className="flex items-start gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center mt-1">
                  <ChevronRight size={20} className="text-white" />
                </div>
                <p className="text-lg text-foreground font-medium">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="section-spacing bg-card">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-foreground">Simple, Affordable Pricing</h2>
          <p className="text-center text-muted-foreground text-lg mb-16">
            Everything you need to automate bookings
          </p>

          <div className="max-w-2xl mx-auto">
            <div className="bg-white border-2 border-primary rounded-2xl p-8 md:p-12 shadow-lg hover:shadow-xl transition-shadow">
              <div className="text-center mb-8">
                <div className="text-5xl md:text-6xl font-bold text-foreground mb-2">
                  ₹199 <span className="text-2xl md:text-3xl text-muted-foreground font-normal">/ month</span>
                </div>
                <p className="text-muted-foreground">only</p>
              </div>

              <ul className="space-y-4 mb-8">
                {[
                  "Unlimited comment automation",
                  "Instagram automation",
                  "Facebook automation",
                  "Automatic DM replies",
                  "Sends your WhatsApp link via Instagram and Facebook DMs",
                  "Booking link integration",
                  "24/7 automation",
                  "Free setup support"
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-foreground">
                    <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                      <ChevronRight size={16} className="text-white" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>

              <a
                href="https://homestay.dizibook.com/sign-up"
                className="btn-primary w-full text-center block mb-4"
              >
                Start Free 7-Day Trial
              </a>
            <p className="text-center text-sm text-muted-foreground">
              Start your 7-day free trial. Cancel anytime.
            </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="section-spacing bg-white">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-foreground">Frequently Asked Questions</h2>

          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="border border-border rounded-lg overflow-hidden">
                <button
                  onClick={() => setOpenFAQ(openFAQ === idx ? null : idx)}
                  className="w-full px-6 py-4 bg-card hover:bg-card/80 transition-colors flex items-center justify-between text-left"
                >
                  <span className="font-semibold text-foreground text-lg">{faq.q}</span>
                  <div className={`transform transition-transform ${openFAQ === idx ? "rotate-180" : ""}`}>
                    <ChevronRight size={20} className="text-primary" />
                  </div>
                </button>
                {openFAQ === idx && (
                  <div className="px-6 py-4 bg-white border-t border-border">
                    <p className="text-muted-foreground">{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="section-spacing bg-gradient-to-r from-primary/10 to-primary/5 border-t border-border">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">Ready to Automate Your Bookings?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Start capturing more bookings from Instagram and Facebook today.
          </p>
          <a
            href="https://homestay.dizibook.com/sign-up"
            className="btn-primary inline-block"
          >
            Start Free 7-Day Trial
          </a>
          <p className="text-sm text-muted-foreground mt-4">
            Start your 7-day free trial. Cancel anytime.
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
